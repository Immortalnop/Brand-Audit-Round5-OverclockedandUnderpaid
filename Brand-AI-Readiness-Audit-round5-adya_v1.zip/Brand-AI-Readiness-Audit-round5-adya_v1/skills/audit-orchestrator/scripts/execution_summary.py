"""execution_summary.py -- ensures every report is fully populated and never
misleading about what did and didn't happen:
site/timestamp/summary/findings/recommendations/coverage/capabilities are
already assembled by run_audit.py; this module adds the three fields that were
previously missing -- `execution_status`, `limitations`, and `confidence` -- all
derived from real signals recorded elsewhere in the run, never hardcoded
boilerplate and never fabricated precision.
"""


def derive_execution_status(deadline, skill_results: list, worker_timeout_events: list) -> str:
    """One of, in priority order:
      "partial_deadline_reached" -- the shared audit deadline was hit
      "degraded"                 -- at least one specialist crashed (status "failed")
      "completed_with_timeouts"  -- at least one specialist was abandoned after
                                     exceeding its per-worker timeout, but the
                                     overall deadline was not hit
      "completed"                -- normal completion
    These are read directly off real state (deadline.expired(), each skill's own
    reported status, and instrumentation's worker-timeout log) -- never inferred
    from counts that could be stale."""
    if deadline.expired():
        return "partial_deadline_reached"
    if any(r.get("status") == "failed" for r in skill_results):
        return "degraded"
    if worker_timeout_events:
        return "completed_with_timeouts"
    return "completed"


def derive_limitations(artifacts, capabilities: dict, coverage: dict, execution_status: str) -> list:
    """Plain-English limitations. Each line is gated on a real signal from this
    run -- nothing here is boilerplate that runs regardless of what happened, and
    nothing that is unassessed is ever implied to have passed."""
    out = []

    if artifacts.robots_data.get("conservative_fail_closed"):
        fetched = coverage.get("pages_fetched_attempted", 0)
        status = artifacts.robots_data.get("status")
        why = ("robots.txt is served behind a bot challenge" if status == "challenged"
               else "robots.txt answered HTTP 429 (rate limited)" if status == "rate_limited"
               else "robots.txt answered a 4xx other than 404, so the server refused this client rather "
                    "than saying no robots file exists" if status == "unavailable_4xx"
               else f"robots.txt could not be reliably retrieved or parsed (status: '{status}')")
        out.append(
            f"{why}; crawl permission is unknown, so the audit fetched {fetched} page(s)"
            + " and most on-site checks are insufficient_evidence rather than confirmed."
        )
        # The fail-closed crawl has exactly one documented exception; it is stated
        # rather than left for a reader to infer from the page count.
        if artifacts.robots_data.get("homepage_diagnostic"):
            out.append("Permission being unknown, the crawl was fail-closed with one stated exception: a single "
                       "homepage request was made without robots directives (none could be obtained) purely to tell "
                       "\"only robots.txt is refused\" apart from \"the whole site is refused\". No link found on "
                       "that page was followed.")
    if "start_url_is_login_page" in (getattr(artifacts, "warnings", None) or ()):
        out.append("The start URL is a login page, which the audit does not analyse; audit the public homepage "
                   "or a public landing page instead.")
    out_of_scope = coverage.get("pages_out_of_scope", 0)
    if out_of_scope:
        out.append(f"{out_of_scope} fetched page(s) were login pages (a password field, little text, no entity "
                   "markup and a login path or heading); they were kept out of the analysed sample and are listed in "
                   "coverage.out_of_scope_pages.")
    challenged = coverage.get("pages_challenged", 0)
    if challenged:
        out.append(f"{challenged} fetched page(s) returned a bot-protection challenge instead of content; they are "
                   "reported as an access problem and excluded from all content checks.")

    never_attempted = coverage.get("pages_never_attempted", 0)
    if never_attempted > 0:
        out.append(
            f"{never_attempted} discovered URL(s) were never fetched (permission, acquisition failure, or "
            f"budget constraints; out of {coverage.get('pages_discovered', 0)} discovered); findings "
            f"reflect the {coverage.get('pages_fetched_attempted', 0)} page(s) actually crawled "
            f"across {coverage.get('templates_sampled', 0)} distinct page template(s), not every URL."
        )

    if coverage.get("pages_timed_out", 0) > 0:
        out.append(
            f"{coverage['pages_timed_out']} page fetch(es) timed out and were not analyzed for content."
        )

    if not capabilities.get("headless_rendering"):
        out.append(
            "Headless browser rendering was not available in this environment; rendering-gap "
            "findings are based on a static-content heuristic only and are reported as "
            "suspected/insufficient_evidence rather than confirmed."
        )

    if not capabilities.get("external_search"):
        out.append(
            "No external search provider was configured; claim corroboration and off-site "
            "footprint assessment were not checked this run (not the same as \"nothing found\")."
        )

    if artifacts.sitemap_data.get("status") not in ("ok", "absent"):
        out.append(
            f"sitemap.xml could not be checked (status: '{artifacts.sitemap_data.get('status')}'); "
            f"crawl coverage may be incomplete relative to a site that publishes one."
        )

    if execution_status == "partial_deadline_reached":
        out.append("The shared audit deadline was reached before every analysis stage finished; "
                    "unfinished work is reported as insufficient_evidence, not silently dropped.")
    elif execution_status == "completed_with_timeouts":
        out.append("At least one analysis specialist exceeded its per-worker time budget and was "
                    "abandoned; its findings are insufficient_evidence rather than fabricated.")
    elif execution_status == "degraded":
        out.append("Acquisition or an analysis specialist could not complete; affected checks remain "
                    "unassessed rather than being treated as passed.")

    return out


SAMPLE_HEURISTIC_PAGES = 20
SAMPLE_HEURISTIC_TEMPLATES = 5


def overall_confidence(coverage: dict, execution_status: str) -> dict:
    """Report-level confidence with its method shown.

    min(sample_quality, access_quality, execution_penalty):
      sample_quality   a CENSUS when every discovered URL was analysed -- the
                       sample is then the site, so the score is 1.0 and a
                       genuinely complete one-page site is not penalised for
                       being small. Otherwise an explicit SIZE HEURISTIC,
                       min(1, pages/20) x min(1, templates/5) floored at 0.3,
                       which says the sample is large and varied enough to be
                       worth trusting. It does NOT establish that the sample is
                       representative of the site, and it does not establish
                       that discovery was complete on a large site; those are
                       separate claims this audit does not make.
      access_quality   = content pages / fetched pages (challenged pages lower it)
      execution_penalty 1.0 completed, 0.7 timeouts/degraded, 0.4 deadline hit
    Identity confidence is deliberately NOT part of this minimum: it only limits
    the off-site findings that depend on knowing who the brand is (scoring.py).
    """
    analysed = coverage.get("pages_analyzed", 0) or 0
    # Login pages kept out of scope are a deliberate exclusion, not an access failure.
    fetched = max(0, (coverage.get("pages_fetched_attempted", 0) or 0) - (coverage.get("pages_out_of_scope", 0) or 0))
    templates = coverage.get("templates_sampled", analysed) or 0
    discovered = coverage.get("pages_discovered", 0) or 0
    never_attempted = coverage.get("pages_never_attempted", 0) or 0
    # A census: the crawler discovered N URLs and analysed all N. Then there is no
    # sampling question left and a complete small site is not marked down for
    # being small. A missing or zero discovered count is unknown, not complete,
    # so it is never read as a census.
    census = bool(analysed > 0 and discovered > 0 and never_attempted == 0
                  and analysed >= discovered and fetched <= analysed)
    if analysed <= 0:
        sample_quality, sample_basis = 0.0, "no_page_analysed"
    elif census:
        sample_quality, sample_basis = 1.0, "census"
    else:
        sample_quality, sample_basis = max(0.3, min(1.0, analysed / SAMPLE_HEURISTIC_PAGES)
                                           * min(1.0, max(1, templates) / SAMPLE_HEURISTIC_TEMPLATES)), "size_heuristic"
    access_quality = 1.0 if fetched <= 0 else min(1.0, analysed / fetched)
    execution_penalty = {
        "completed": 1.0, "completed_with_timeouts": 0.7,
        "degraded": 0.7, "partial_deadline_reached": 0.4,
    }.get(execution_status, 0.5)
    score = min(sample_quality, access_quality, execution_penalty)
    parts = {"sample_quality": sample_quality, "access_quality": access_quality, "execution_penalty": execution_penalty}
    limiting = min(parts, key=lambda k: (parts[k], list(parts).index(k)))
    identity = coverage.get("identity_confidence", 0.0) or 0.0
    reasons = {
        "sample_quality": ("No content page could be analysed." if not analysed else
                           f"Every discovered URL was analysed ({analysed} content page(s) across {templates} "
                           "template(s)), so this is the whole site, not a sample of it." if census else
                           f"{analysed} content page(s) across {templates} distinct page template(s) were analysed. "
                           f"This score is an explicit size heuristic ({SAMPLE_HEURISTIC_PAGES} pages across "
                           f"{SAMPLE_HEURISTIC_TEMPLATES} templates scores 1.0); it says the sample is large and "
                           "varied enough to be worth trusting, not that it is representative of the site or that "
                           "discovery was complete."),
        "access_quality": (f"{analysed} of {fetched} fetched page(s) returned real content"
                           + ((f"; {coverage['pages_challenged']} was a bot challenge or rate limit"
                               if coverage["pages_challenged"] == 1 else
                               f"; {coverage['pages_challenged']} were bot challenges or rate limits")
                              if coverage.get("pages_challenged") else "") + "." if fetched
                           else "No page was fetched."),
        "execution_penalty": {"completed": "The audit run completed normally.",
                              "completed_with_timeouts": "At least one analysis step timed out.",
                              "degraded": "Acquisition or an analysis step could not complete.",
                              "partial_deadline_reached": "The time limit was reached before every step finished.",
                              }.get(execution_status, "The audit run did not complete normally."),
    }
    level = confidence_level(score)
    explanation = (f"Confidence is {level} ({score:.2f}). "
                   + ("Every part holds up." if score >= 0.75 else
                      f"It is limited by {limiting.replace('_', ' ')}: {reasons[limiting]}")
                   + f" Brand identity confidence is {identity:.2f}; it limits only the off-site findings, "
                     "not this score.")
    return {
        "score": round(score, 2),
        "level": level,
        "limiting_factor": limiting,
        "method": "min(sample_quality, access_quality, execution_penalty); sample_quality is 1.0 for a census "
                  "(every discovered URL analysed) and otherwise the size heuristic min(1, pages/20) x "
                  "min(1, templates/5), floored at 0.3 -- a judgement about sample size and variety, not a "
                  "measurement of representativeness or of discovery completeness. Identity confidence limits "
                  "only off-site findings.",
        "sample_basis": sample_basis,
        "components": {
            "sample_quality": round(sample_quality, 2),
            "access_quality": round(access_quality, 2),
            "execution_penalty": round(execution_penalty, 2),
            "identity_confidence": round(identity, 2),
        },
        "reasons": reasons,
        "explanation": explanation,
    }


def confidence_level(score):
    """high (>= 0.75), medium (>= 0.4) or low: a word a non-expert can act on."""
    return "high" if score >= 0.75 else "medium" if score >= 0.4 else "low"
